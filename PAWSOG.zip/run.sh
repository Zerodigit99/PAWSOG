#!/usr/bin/env bash

# Exit immediately if a command exits with a non-zero status
set -e

echo "Starting the bot..."

# Run the bot
python main.py